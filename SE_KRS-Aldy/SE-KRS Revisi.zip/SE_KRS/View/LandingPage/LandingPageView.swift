// File: View/LandingPage/LandingPageView.swift (FINAL REVISION)
import SwiftUI

struct LandingView: View {
    var body: some View {
        NavigationView {
            ZStack {
                // GRUP 1: Latar Belakang (di paling bawah)
                // Dibuat agar memenuhi seluruh layar, mengabaikan safe area.
                ZStack {
                    Image("foods")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                    
                    LinearGradient(
                        gradient: Gradient(colors: [.black.opacity(0.2), .black.opacity(0.7)]),
                        startPoint: .top,
                        endPoint: .bottom
                    )
                }
                .edgesIgnoringSafeArea(.all)

                // GRUP 2: Konten (Teks dan Tombol)
                // Ditempatkan di atas latar belakang.
                VStack {
                    Spacer() // Mendorong konten ke bawah
                    
                    VStack(spacing: 15) {
                        Text("Pesan Makanan Favoritmu, Kapan Saja.")
                            .font(.system(size: 10, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .shadow(radius: 5)
                        
                        Text("Temukan restoran terbaik dan nikmati hidangan lezat diantar ke pintumu.")
                            .font(.subheadline)
                            .foregroundColor(.white.opacity(0.9))
                            .multilineTextAlignment(.center)
                            .padding(.bottom, 20)
                        
                        // Tombol Masuk
                        NavigationLink(destination: LoginView()) {
                            Text("MASUK")
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.red)
                                .cornerRadius(15)
                        }
                        
                        // Tombol Daftar
                        NavigationLink(destination: SignUpView()) {
                            Text("DAFTAR SEKARANG")
                                .fontWeight(.bold)
                                .foregroundColor(.red)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(.white)
                                .cornerRadius(15)
                        }
                    }
                    // PENYESUAIAN KUNCI: Padding diterapkan di sini
                    // Padding ini akan memberi jarak dari tepi kiri, kanan, dan bawah layar
                    // karena VStack ini tidak mengabaikan safe area.
                    .padding(.horizontal, 25)
                    .padding(.bottom, 40)
                }
            }
            .navigationBarHidden(true)
        }
        .accentColor(.red)
    }
}
